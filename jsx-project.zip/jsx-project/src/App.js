import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">Hello Dojo!
        <p>Things I need to do:</p>
          <ul>
            <li>Learn React</li>
            <li>Climb Mt. Everest</li>
            <li>Run a Marathon</li>
            <li>Feed the Dogs</li>
          </ul>
      </header>
    </div>
  );
}

export default App;
